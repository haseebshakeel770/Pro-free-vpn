# ProVPN — سیٹ اپ گائیڈ

## 1) ہر سرور پر WireGuard لگائیں (Ubuntu/Debian VPS)
    curl -O https://raw.githubusercontent.com/angristan/wireguard-install/master/wireguard-install.sh
    chmod +x wireguard-install.sh && sudo ./wireguard-install.sh
اسکرپٹ آخر میں ایک کلائنٹ `.conf` فائل بنا دے گی۔ پورٹ UDP 51820 فائروال میں کھلی ہونی چاہیے۔

## 2) کنفیگ ایپ میں ڈالیں (دو طریقے)
- **طریقہ A:** `app/src/main/assets/servers.json` میں ہر سرور کے لیے `endpoint`, `serverPublicKey`, `clientPrivateKey`, `clientAddress` بھریں (`.conf` سے ملتی ہیں: PublicKey, PrivateKey, Address)۔
- **طریقہ B:** ایپ کھول کر Change ← Import میں `.conf` کا پورا ٹیکسٹ پیسٹ کر دیں۔

## 3) APK بنائیں
پورا فولڈر GitHub پر اپلوڈ کریں ← Actions ٹیب ← "Build APK" ← آخر میں Artifacts سے `ProVPN-apk` ڈاؤنلوڈ کریں۔

## نوٹ
- ایک ہی کلائنٹ کی (key) سب یوزرز میں شیئر کرنا صرف ذاتی/ٹیسٹ کے لیے ٹھیک ہے۔ پبلک ایپ کے لیے ہر یوزر کی الگ key اور ایک بیک اینڈ API چاہیے۔
- غلط key ہو تو ایپ "Protected" دکھا سکتی ہے مگر انٹرنیٹ نہیں چلے گا۔ پہلے آفیشل WireGuard ایپ سے کنفیگ ٹیسٹ کر لیں۔
