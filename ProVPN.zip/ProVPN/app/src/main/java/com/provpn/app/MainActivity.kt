package com.provpn.app

import android.app.Activity
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme

class MainActivity : ComponentActivity() {
    private val vm: VpnViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) vm.connect() else vm.permissionDenied()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                VpnScreen(vm) { toggle() }
            }
        }
    }

    private fun toggle() {
        when (vm.status) {
            Status.CONNECTED, Status.CONNECTING -> vm.disconnect()
            Status.DISCONNECTED -> {
                val intent = VpnService.prepare(this)
                if (intent != null) permissionLauncher.launch(intent) else vm.connect()
            }
        }
    }
}
