package com.provpn.app

import android.app.Application
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

enum class Status { DISCONNECTED, CONNECTING, CONNECTED }

class VpnViewModel(app: Application) : AndroidViewModel(app) {
    private val ctl = (app as VpnApp).controller

    var servers by mutableStateOf(ServerStore.load(app))
    var selected by mutableStateOf(servers.firstOrNull())
    var status by mutableStateOf(Status.DISCONNECTED)
    var error by mutableStateOf<String?>(null)
    var since by mutableLongStateOf(0L)

    init {
        if (ctl.isUp()) { status = Status.CONNECTED; since = SystemClock.elapsedRealtime() }
    }

    fun connect() {
        val s = selected ?: run { error = "No server selected"; return }
        status = Status.CONNECTING
        error = null
        viewModelScope.launch {
            runCatching { ctl.connect(s) }
                .onSuccess { status = Status.CONNECTED; since = SystemClock.elapsedRealtime() }
                .onFailure { status = Status.DISCONNECTED; error = it.message ?: "Connection failed" }
        }
    }

    fun disconnect() {
        viewModelScope.launch {
            runCatching { ctl.disconnect() }
            status = Status.DISCONNECTED
        }
    }

    fun select(s: VpnServer) {
        selected = s
        if (status == Status.CONNECTED) connect()
    }

    fun permissionDenied() { status = Status.DISCONNECTED; error = "VPN permission denied" }

    fun importConf(name: String, text: String): Boolean {
        val s = ServerStore.fromConf(name, text) ?: return false
        ServerStore.addCustom(getApplication(), s)
        servers = ServerStore.load(getApplication())
        selected = s
        return true
    }
}
