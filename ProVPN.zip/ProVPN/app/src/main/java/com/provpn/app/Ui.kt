package com.provpn.app

import android.os.SystemClock
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Purple = Color(0xFF7C5CFF)
private val Green = Color(0xFF22D3A6)
private val Amber = Color(0xFFFFB020)
private val Card = Color(0xFF1A1F4A)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VpnScreen(vm: VpnViewModel, onToggle: () -> Unit) {
    var showSheet by remember { mutableStateOf(false) }
    var showImport by remember { mutableStateOf(false) }
    var elapsed by remember { mutableLongStateOf(0L) }

    LaunchedEffect(vm.status, vm.since) {
        while (vm.status == Status.CONNECTED) {
            elapsed = (SystemClock.elapsedRealtime() - vm.since) / 1000
            delay(1000)
        }
        elapsed = 0
    }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0B1020), Color(0xFF1A1245), Color(0xFF0B1020))))
            .systemBarsPadding()
    ) {
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("ProVPN", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Fast • Private • Secure", color = Color(0xFF9AA3D0), fontSize = 13.sp)
            Spacer(Modifier.weight(1f))
            ConnectButton(vm.status, onToggle)
            Spacer(Modifier.height(20.dp))
            Text(
                when (vm.status) {
                    Status.DISCONNECTED -> "Not Connected"
                    Status.CONNECTING -> "Connecting…"
                    Status.CONNECTED -> "Protected"
                },
                color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold
            )
            if (vm.status == Status.CONNECTED) {
                Text(
                    "%02d:%02d:%02d".format(elapsed / 3600, (elapsed % 3600) / 60, elapsed % 60),
                    color = Green, fontSize = 18.sp, modifier = Modifier.padding(top = 6.dp)
                )
            } else {
                Text("Tap the button to connect", color = Color(0xFF9AA3D0), fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
            }
            vm.error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp)) }
            Spacer(Modifier.weight(1f))

            val s = vm.selected
            Row(
                Modifier.fillMaxWidth().background(Card, RoundedCornerShape(20.dp))
                    .clickable { showSheet = true }.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(s?.flag ?: "🌐", fontSize = 34.sp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(s?.country ?: "Select server", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                    Text(s?.city ?: "", color = Color(0xFF9AA3D0), fontSize = 13.sp)
                }
                Text("Change ›", color = Purple, fontWeight = FontWeight.Medium)
            }
        }
    }

    if (showSheet) {
        ModalBottomSheet(onDismissRequest = { showSheet = false }, containerColor = Color(0xFF14183A)) {
            Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Choose Location", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { showImport = true }) { Text("+ Import", color = Purple) }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(vm.servers) { sv ->
                        val sel = sv.id == vm.selected?.id
                        Row(
                            Modifier.fillMaxWidth()
                                .background(if (sel) Purple.copy(alpha = 0.25f) else Card, RoundedCornerShape(16.dp))
                                .clickable { vm.select(sv); showSheet = false }.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(sv.flag, fontSize = 28.sp)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(sv.country, color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text(sv.city, color = Color(0xFF9AA3D0), fontSize = 12.sp)
                            }
                            if (sel) Text("✓", color = Green, fontSize = 20.sp)
                        }
                    }
                }
            }
        }
    }

    if (showImport) {
        var name by remember { mutableStateOf("") }
        var conf by remember { mutableStateOf("") }
        var bad by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showImport = false },
            title = { Text("Import WireGuard config") },
            text = {
                Column {
                    OutlinedTextField(name, { name = it }, label = { Text("Name (e.g. USA)") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(conf, { conf = it; bad = false }, label = { Text("Paste .conf text") }, minLines = 5, maxLines = 8)
                    if (bad) Text("Invalid config", color = Color(0xFFFF6B6B), fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { if (vm.importConf(name, conf)) { showImport = false; showSheet = false } else bad = true }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showImport = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun ConnectButton(status: Status, onClick: () -> Unit) {
    val color by animateColorAsState(
        when (status) { Status.DISCONNECTED -> Purple; Status.CONNECTING -> Amber; Status.CONNECTED -> Green },
        label = "c"
    )
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(
        0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart), label = "pp"
    )
    Box(
        Modifier.size(270.dp).clickable(remember { MutableInteractionSource() }, null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val base = size.minDimension * 0.31f
            if (status != Status.DISCONNECTED) {
                for (i in 0..1) {
                    val p = (pulse + i * 0.5f) % 1f
                    drawCircle(color.copy(alpha = (1f - p) * 0.4f), radius = base + p * size.minDimension * 0.19f, style = Stroke(3f))
                }
            }
            drawCircle(color.copy(alpha = 0.15f), radius = base * 1.18f)
            drawCircle(Brush.radialGradient(listOf(color, color.copy(alpha = 0.6f))), radius = base)
            val r = base * 0.38f
            drawArc(Color.White, -60f, 300f, false, Offset(c.x - r, c.y - r), Size(2 * r, 2 * r), style = Stroke(10f, cap = StrokeCap.Round))
            drawLine(Color.White, Offset(c.x, c.y - r * 1.2f), Offset(c.x, c.y), 10f, StrokeCap.Round)
        }
    }
}
