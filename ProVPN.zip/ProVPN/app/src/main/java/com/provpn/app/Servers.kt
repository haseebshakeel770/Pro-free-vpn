package com.provpn.app

import android.content.Context
import com.wireguard.config.Config
import com.wireguard.config.InetAddresses
import com.wireguard.config.InetEndpoint
import com.wireguard.config.InetNetwork
import com.wireguard.config.Interface
import com.wireguard.config.Peer
import org.json.JSONArray
import org.json.JSONObject

data class VpnServer(
    val id: String,
    val country: String,
    val city: String,
    val flag: String,
    val endpoint: String,
    val serverPublicKey: String,
    val clientPrivateKey: String,
    val clientAddress: String,
    val dns: String = "1.1.1.1",
    val mtu: Int = 1280,
)

fun VpnServer.toConfig(): Config {
    val ib = Interface.Builder().parsePrivateKey(clientPrivateKey).setMtu(mtu)
    clientAddress.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        .forEach { ib.addAddress(InetNetwork.parse(it)) }
    dns.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        .forEach { ib.addDnsServer(InetAddresses.parse(it)) }
    val peer = Peer.Builder()
        .parsePublicKey(serverPublicKey)
        .addAllowedIp(InetNetwork.parse("0.0.0.0/0"))
        .addAllowedIp(InetNetwork.parse("::/0"))
        .setEndpoint(InetEndpoint.parse(endpoint))
        .setPersistentKeepalive(25)
        .build()
    return Config.Builder().setInterface(ib.build()).addPeer(peer).build()
}

object ServerStore {
    private fun prefs(c: Context) = c.getSharedPreferences("provpn", Context.MODE_PRIVATE)

    fun load(c: Context): List<VpnServer> {
        val base = runCatching {
            parse(c.assets.open("servers.json").bufferedReader().readText())
        }.getOrDefault(emptyList())
        val custom = runCatching { parse(prefs(c).getString("custom", "[]")!!) }.getOrDefault(emptyList())
        return base + custom
    }

    private fun parse(json: String): List<VpnServer> {
        val a = JSONArray(json)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            VpnServer(
                o.getString("id"), o.getString("country"), o.optString("city", ""),
                o.optString("flag", "🌐"), o.getString("endpoint"), o.getString("serverPublicKey"),
                o.getString("clientPrivateKey"), o.getString("clientAddress"),
                o.optString("dns", "1.1.1.1"), o.optInt("mtu", 1280)
            )
        }
    }

    fun addCustom(c: Context, s: VpnServer) {
        val arr = JSONArray(prefs(c).getString("custom", "[]"))
        arr.put(JSONObject().apply {
            put("id", s.id); put("country", s.country); put("city", s.city); put("flag", s.flag)
            put("endpoint", s.endpoint); put("serverPublicKey", s.serverPublicKey)
            put("clientPrivateKey", s.clientPrivateKey); put("clientAddress", s.clientAddress)
            put("dns", s.dns); put("mtu", s.mtu)
        })
        prefs(c).edit().putString("custom", arr.toString()).apply()
    }

    /** Parses a standard WireGuard .conf text into a server entry. */
    fun fromConf(name: String, text: String): VpnServer? {
        val m = mutableMapOf<String, String>()
        text.lines().forEach { line ->
            val i = line.indexOf('=')
            if (i > 0 && !line.trim().startsWith("#")) m[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
        }
        val priv = m["privatekey"] ?: return null
        val addr = m["address"] ?: return null
        val pub = m["publickey"] ?: return null
        val ep = m["endpoint"] ?: return null
        return VpnServer(
            "custom_${System.currentTimeMillis()}", name.ifBlank { "Custom" }, ep, "🌐",
            ep, pub, priv, addr, m["dns"] ?: "1.1.1.1", m["mtu"]?.toIntOrNull() ?: 1280
        )
    }
}
