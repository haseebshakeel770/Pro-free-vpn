package com.provpn.app

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class VpnController(context: Context) {
    private val backend = GoBackend(context)
    private val tunnel = object : Tunnel {
        override fun getName(): String = "provpn"
        override fun onStateChange(newState: Tunnel.State) {}
    }

    suspend fun connect(s: VpnServer) = withContext(Dispatchers.IO) {
        backend.setState(tunnel, Tunnel.State.UP, s.toConfig())
    }

    suspend fun disconnect() = withContext(Dispatchers.IO) {
        backend.setState(tunnel, Tunnel.State.DOWN, null)
    }

    fun isUp(): Boolean = backend.getState(tunnel) == Tunnel.State.UP
}
