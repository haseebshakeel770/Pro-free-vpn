package com.provpn.app

import android.app.Application

class VpnApp : Application() {
    lateinit var controller: VpnController
    override fun onCreate() {
        super.onCreate()
        controller = VpnController(this)
    }
}
